﻿using Polly;

static List<int> Generate15Fibonacci(bool isFast = false)
{
    // directly return the list of fibonacci numbers if isFast is true
    if (isFast)
    {
        return [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377];
    }

    // generate the list of fibonacci numbers if isFast is false
    const int targetCount = 15;
    var fibonacciNumbers = new List<int> { 0, 1 };
    for (int i = 2; i < targetCount; i++)
    {
        fibonacciNumbers.Add(fibonacciNumbers[i - 1] + fibonacciNumbers[i - 2]);
    }
    return fibonacciNumbers;
}

var path = Path.Combine(Environment.CurrentDirectory, "Fibonacci.txt");
var fibonacciNumbers = Generate15Fibonacci(true);

const int retryCount = 3;
var retryPolicy = Policy
    .Handle<IOException>()
    .WaitAndRetryAsync(retryCount, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

await retryPolicy.ExecuteAsync(async () =>
{
    await File.WriteAllTextAsync(path, string.Join(",", fibonacciNumbers));
});

Console.WriteLine("Fibonacci numbers written to file successfully!");

