﻿using System.Text;

const string questionString = "Enter an integer: ";
const string invalidInputString = "Please enter a valid number";

static void AskQuestion()
{
    Console.Write(questionString);
}

static void PrintInvalidInputMessage()
{
    Console.WriteLine(invalidInputString);
}

while (true)
{
    int tempNum;
    AskQuestion();

    // Validate if the input is a number
    string input = Console.ReadLine();
    while (!int.TryParse(input, out tempNum))
    {
        PrintInvalidInputMessage();
        AskQuestion();
        input = Console.ReadLine();
    }

    int sum = 0;
    StringBuilder sb = new();

    for (int i = 1; i <= tempNum; i++)
    {
        if (i % 3 == 0 || i % 5 == 0)
        {
            sum += i;
            sb.Append(i + " + ");
        }
    }

    if (sb.Length > 2)
    {
        sb.Remove(sb.Length - 2, 2);
    }

    sb.Append("= " + sum);

    Console.WriteLine(sb.ToString());
}
