﻿using OpenSenseMapAPI.Domain;
using System.ComponentModel.DataAnnotations;

namespace OpenSenseMapAPI.Contracts.User
{
    public class LoginUserRequest
    {
        [Required]
        public string email { get; set; }
        [Required]
        public string password { get; set; }

        public UserLogin ToDomain()
        {
            return new UserLogin
            {
                Email = email,
                Password = password
            };
        }
    }
}
