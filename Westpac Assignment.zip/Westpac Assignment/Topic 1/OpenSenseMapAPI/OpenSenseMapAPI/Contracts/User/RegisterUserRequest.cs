﻿using OpenSenseMapAPI.Domain;
using System.ComponentModel.DataAnnotations;

namespace OpenSenseMapAPI.Contracts.User
{
    public class RegisterUserRequest
    {
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9][a-zA-Z0-9._ -]{2,39}$", ErrorMessage = "The name must consist of at least 3 and up to 40 characters and only allows to use alphanumerics (a-zA-Z0-9), dots (.), dashes (-), underscores (_) and spaces. The first character must be a letter or number.")]
        public string name { get; set; }

        [Required]
        [EmailAddress]
        public string email { get; set; }

        [Required]
        [MinLength(8, ErrorMessage = "Password must be at least 8 characters long")]
        public string password { get; set; }

        public Domain.User ToDomain()
        {
            return new Domain.User
            {
                Name = name,
                Email = email,
                Password = password
            };
        }
    }
}
