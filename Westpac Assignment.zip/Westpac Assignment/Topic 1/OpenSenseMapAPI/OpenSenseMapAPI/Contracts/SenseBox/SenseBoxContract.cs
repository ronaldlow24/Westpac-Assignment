﻿using OpenSenseMapAPI.Domain;

namespace OpenSenseMapAPI.Contracts.SenseBox
{
    public class SenseBoxContract
    {
        public string _id { get; set; }
        public string name { get; set; }
        public string exposure { get; set; }
        public string model { get; set; }
        public DateTimeOffset lastMeasurementAt { get; set; }
        public string? weblink { get; set; }
        public string? description { get; set; }
        public DateTimeOffset createdAt { get; set; }
        public DateTimeOffset updatedAt { get; set; }
        public List<string> grouptag { get; set; }
        public CurrentLocationContract currentLocation { get; set; }
        public string? image { get; set; }
        public List<SensorContract> sensors { get; set; }

        public static SenseBoxContract FromDomain(Domain.SenseBox senseBox)
        {
            return new SenseBoxContract
            {
                _id = senseBox.Id,
                name = senseBox.Name,
                exposure = senseBox.Exposure,
                model = senseBox.Model,
                lastMeasurementAt = senseBox.LastMeasurementAt,
                weblink = senseBox.Weblink,
                description = senseBox.Description,
                createdAt = senseBox.CreatedAt,
                updatedAt = senseBox.UpdatedAt,
                grouptag = senseBox.Grouptag,
                currentLocation = CurrentLocationContract.FromDomain(senseBox.CurrentLocation),
                image = senseBox.Image,
                sensors = senseBox.Sensors.Select(SensorContract.FromDomain).ToList()
            };
        }
    }

    public class CurrentLocationContract
    {
        public string type { get; set; }
        public List<decimal> coordinates { get; set; }
        public DateTimeOffset timestamp { get; set; }

        public static CurrentLocationContract FromDomain(CurrentLocation currentLocation)
        {
            return new CurrentLocationContract
            {
                type = currentLocation.Type,
                coordinates = currentLocation.Coordinates,
                timestamp = currentLocation.Timestamp
            };
        }
    }

    public class SensorContract
    {
        public string _id { get; set; }
        public string title { get; set; }
        public string sensorType { get; set; }
        public string unit { get; set; }
        public string? icon { get; set; }
        public MeasurementContract? lastMeasurement { get; set; }

        public static SensorContract FromDomain(Sensor sensor)
        {
            return new SensorContract
            {
                _id = sensor.Id,
                title = sensor.Title,
                sensorType = sensor.SensorType,
                unit = sensor.Unit,
                icon = sensor.Icon,
                lastMeasurement = sensor.LastMeasurement is not null ? MeasurementContract.FromDomain(sensor.LastMeasurement) : null
            };
        }

    }

    public class MeasurementContract
    {
        public string value { get; set; }
        public DateTimeOffset createdAt { get; set; }
        public static MeasurementContract FromDomain(Measurement measurement)
        {
            return new MeasurementContract
            {
                value = measurement.Value,
                createdAt = measurement.CreatedAt
            };
        }
    }

}
