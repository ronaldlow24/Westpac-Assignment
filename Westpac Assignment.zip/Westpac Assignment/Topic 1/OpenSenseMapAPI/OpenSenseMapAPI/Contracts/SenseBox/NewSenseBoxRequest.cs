﻿using OpenSenseMapAPI.Domain;
using System.ComponentModel.DataAnnotations;

namespace OpenSenseMapAPI.Contracts.SenseBox
{
    public class NewSenseBoxRequest
    {
        [Required]
        public string email { get; set; }
        [Required]
        public string name { get; set; }
        [Required]
        [RegularExpression("indoor|outdoor|mobile|unknown")]
        public string exposure { get; set; }
        [Required]
        [RegularExpression("homeV2Lora|homeV2Ethernet|homeV2Wifi|homeEthernet|homeWifi|homeEthernetFeinstaub|homeWifiFeinstaub|luftdaten_sds011|luftdaten_sds011_dht11|luftdaten_sds011_dht22|luftdaten_sds011_bmp180|luftdaten_sds011_bme280|hackair_home_v2")]
        public string model { get; set; }
        [Required]
        public NewSenseBoxRequestSenseBoxLocation location { get; set; }

        public Domain.SenseBox ToDomain()
        {
            return new Domain.SenseBox
            {
                Name = name,
                Exposure = exposure,
                Model = model,
                CurrentLocation = new CurrentLocation
                {
                    Type = "Point",
                    Coordinates = new List<decimal> { location.lng, location.lat, location.height },
                    Timestamp = DateTimeOffset.UtcNow
                }
            };
        }
    }

    public class NewSenseBoxRequestSenseBoxLocation
    {
        [Required]
        [Range(-90,90)]
        public decimal lat { get; set; }
        [Required]
        [Range(-180, 180)]
        public decimal lng { get; set; }
        [Required]
        [Range(0, int.MaxValue)]
        public decimal height { get; set; }
    }
}
