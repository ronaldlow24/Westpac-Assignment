﻿namespace OpenSenseMapAPI.Utils.TypedHttpClient
{
    public class OpenSenseMapHttpClient
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public OpenSenseMapHttpClient(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _httpClient.BaseAddress = new Uri(_configuration["OpenSenseMapApi:BaseAddress"]!);
        }

        public HttpClient GetHttpClient()
        {
            return _httpClient;
        }

    }
}
