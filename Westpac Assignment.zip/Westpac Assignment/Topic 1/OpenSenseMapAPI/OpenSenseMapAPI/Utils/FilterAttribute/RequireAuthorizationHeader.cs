using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace OpenSenseMapAPI.Utils.FilterAttribute
{
    public class RequireAuthorizationHeader : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            
            if (string.IsNullOrWhiteSpace(context.HttpContext.Request.Headers.Authorization))
            {
                context.Result = new UnauthorizedObjectResult("Authorization header is required");
                return;
            }
            
            base.OnActionExecuting(context);
        }
    }
}
