﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace OpenSenseMapAPI.Middleware
{
    public class HandleException(IProblemDetailsService problemDetailsService) : IExceptionHandler
    {
        public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
        {
            var problem = new ProblemDetails
            {
                Detail = exception.Message,
                Status = StatusCodes.Status400BadRequest,
                Type = "Bad Request",
                Title = "Exception"
            };

            var errorContext = new ProblemDetailsContext
            {
                HttpContext = httpContext,
                Exception = exception,
                ProblemDetails = problem
            };
            httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
            await problemDetailsService.WriteAsync(errorContext);
            return true;
        }
    }
}
