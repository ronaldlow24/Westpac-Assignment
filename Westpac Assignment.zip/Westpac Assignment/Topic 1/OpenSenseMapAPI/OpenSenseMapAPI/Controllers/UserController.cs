using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using OpenSenseMapAPI.Contracts.User;
using OpenSenseMapAPI.Services;
using OpenSenseMapAPI.Utils.FilterAttribute;
using System.ComponentModel.DataAnnotations;

namespace OpenSenseMapAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class UserController : ControllerBase
{
    private readonly ILogger<UserController> _logger;
    private readonly UserService _userService;
    private readonly IMemoryCache _memoryCache;

    public UserController(ILogger<UserController> logger, UserService userService, IMemoryCache memoryCache)
    {
        _logger = logger;
        _userService = userService;
        _memoryCache = memoryCache;
    }

    [HttpPost(nameof(RegisterUser))]
    public async Task<ActionResult> RegisterUser([Required] RegisterUserRequest input)
    {
        try
        {
            var user = input.ToDomain();

            var registerUserResult = await _userService.RegisterUserAsync(user);

            return StatusCode((int)registerUserResult.statusCode, new RegisterUserResponse{
                code = registerUserResult.code,
                message = registerUserResult.message,
                token = registerUserResult.token,
                refreshToken = registerUserResult.refreshToken,
                data = registerUserResult.data
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while registering user - {input}", System.Text.Json.JsonSerializer.Serialize(input));
            throw;
        }
    }

    [HttpPost(nameof(LoginUser))]
    public async Task<ActionResult<LoginUserResponse>> LoginUser([Required] LoginUserRequest input)
    {
        try
        {
            var userLogin = input.ToDomain();

            var loginUserResult = await _userService.LoginUserAsync(userLogin);

            return loginUserResult.Match<ActionResult>(
                response => {
                    _memoryCache.Set(response.token, userLogin.Email);
                    return Ok(new LoginUserResponse
                    {
                        code = response.code,
                        message = response.message,
                        token = response.token,
                        refreshToken = response.refreshToken,
                        data = response.data
                    });
                },
                none => Unauthorized()
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while logging in user - {input}", System.Text.Json.JsonSerializer.Serialize(input));
            throw;
        }
    }

    [HttpPost(nameof(LogoutUser))]
    [RequireAuthorizationHeader]
    public async Task<ActionResult> LogoutUser()
    {
        try
        {
            var token = Request.Headers.Authorization.ToString().Replace("Bearer ", "");

            var logoutUserResult = await _userService.LogoutUserAsync(token);

            return logoutUserResult.Match<ActionResult>(
                success => {
                    _memoryCache.Remove(token);
                    return Ok();
                },
                fail => Unauthorized()
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while logging out user");
            throw;
        }
    }


}
