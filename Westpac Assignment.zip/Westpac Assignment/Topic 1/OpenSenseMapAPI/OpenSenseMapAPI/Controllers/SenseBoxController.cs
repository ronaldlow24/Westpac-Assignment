using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using OpenSenseMapAPI.Contracts.SenseBox;
using OpenSenseMapAPI.Services;
using OpenSenseMapAPI.Utils.FilterAttribute;
using System.ComponentModel.DataAnnotations;

namespace OpenSenseMapAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class SenseBoxController : ControllerBase
{
    private readonly ILogger<SenseBoxController> _logger;
    private readonly SenseBoxService _senseBoxService;
    private readonly IMemoryCache _memoryCache;

    public SenseBoxController(ILogger<SenseBoxController> logger, SenseBoxService senseBoxService, IMemoryCache memoryCache)
    {
        _logger = logger;
        _senseBoxService = senseBoxService;
        _memoryCache = memoryCache;
    }

    [HttpPost(nameof(NewSenseBox))]
    [RequireAuthorizationHeader]
    public async Task<ActionResult<SenseBoxContract>> NewSenseBox([Required] NewSenseBoxRequest input)
    {
        try
        {
            var token = Request.Headers.Authorization.ToString().Replace("Bearer ", "");
            var emailCached = _memoryCache.Get<string>(token);
            if (string.IsNullOrWhiteSpace(emailCached) || !emailCached.Equals(input.email, StringComparison.CurrentCultureIgnoreCase))
            {
                return Unauthorized();
            }

            var senseBox = input.ToDomain();

            var newSenseBoxResult = await _senseBoxService.NewSenseBoxAsync(senseBox, token);

            return Ok(SenseBoxContract.FromDomain(newSenseBoxResult));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while creating new sensebox - {input}", System.Text.Json.JsonSerializer.Serialize(input));
            throw;
        }
    }

    [HttpGet(nameof(GetSenseBoxById))]
    public async Task<ActionResult<SenseBoxContract>> GetSenseBoxById([Required] string senseBoxId)
    {
        try
        {
            var getSenseBoxResult = await _senseBoxService.GetSenseBoxByIdAsync(senseBoxId);

            return getSenseBoxResult.Match<ActionResult>(
                senseBox => Ok(SenseBoxContract.FromDomain(senseBox)),
                none => NotFound()
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error while getting sensebox by id - {senseBoxId}", senseBoxId);
            throw;
        }
    }

}
