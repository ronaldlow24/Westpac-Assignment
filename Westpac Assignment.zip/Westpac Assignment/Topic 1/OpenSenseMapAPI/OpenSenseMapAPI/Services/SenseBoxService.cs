﻿using Microsoft.Extensions.Caching.Memory;
using OneOf;
using OneOf.Types;
using OpenSenseMapAPI.Domain;
using OpenSenseMapAPI.Models.User;
using System.Net;
using System.Text;
using static System.Net.Mime.MediaTypeNames;
using OpenSenseMapAPI.Utils.TypedHttpClient;
using System.Net.Http.Headers;
using OpenSenseMapAPI.Models.SenseBox;

namespace OpenSenseMapAPI.Services
{
    public class SenseBoxService
    {
        private readonly ILogger<SenseBoxService> _logger;
        private readonly OpenSenseMapHttpClient _openSenseMapHttpClient;

        public SenseBoxService(ILogger<SenseBoxService> logger, OpenSenseMapHttpClient openSenseMapHttpClient)
        {
            _logger = logger;
            _openSenseMapHttpClient = openSenseMapHttpClient;
        }

        public async Task<SenseBox> NewSenseBoxAsync(SenseBox senseBox, string token)
        {
            try
            {
                var requestBody = new OpenSenseMapNewSenseBoxRequest
                {
                    name = senseBox.Name,
                    exposure = senseBox.Exposure,
                    model = senseBox.Model,
                    location = new OpenSenseMapNewSenseBoxRequestSenseBoxLocation
                    {
                        lat = senseBox.CurrentLocation.Coordinates[1],
                        lng = senseBox.CurrentLocation.Coordinates[0],
                        height = senseBox.CurrentLocation.Coordinates[2]
                    }
                };
                var requestBodyJson = new StringContent(System.Text.Json.JsonSerializer.Serialize(requestBody), Encoding.UTF8, Application.Json);

                var request = new HttpRequestMessage(HttpMethod.Post, "/boxes");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                request.Content = requestBodyJson;
                using var httpResponseMessage = await _openSenseMapHttpClient.GetHttpClient().SendAsync(request);

                httpResponseMessage.EnsureSuccessStatusCode();
 
                var responseBody = await httpResponseMessage.Content.ReadFromJsonAsync<OpenSenseMapNewSenseBoxResponse>();

                if (responseBody is null)
                {
                    throw new Exception("Failed to deserialize response body");
                }

                return responseBody.data.ToDomain();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while creating new sensebox - {senseBox}", System.Text.Json.JsonSerializer.Serialize(senseBox));
                throw;
            }
        }

        public async Task<OneOf<SenseBox, None>> GetSenseBoxByIdAsync(string senseBoxId)
        {
            try
            {
                using var httpResponseMessage = await _openSenseMapHttpClient.GetHttpClient().GetAsync($"/boxes/{senseBoxId}");

                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    return new None();
                }

                var responseBody = await httpResponseMessage.Content.ReadFromJsonAsync<SenseBoxDTO>();

                if (responseBody is null)
                {
                    throw new Exception("Failed to deserialize response body");
                }

                return responseBody.ToDomain();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while getting sensebox by id - {senseBoxId}", senseBoxId);
                throw;
            }
        }
    }
}
