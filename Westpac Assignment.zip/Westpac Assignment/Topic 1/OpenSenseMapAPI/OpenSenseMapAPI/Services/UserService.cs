﻿using Microsoft.Extensions.Caching.Memory;
using OpenSenseMapAPI.Domain;
using OpenSenseMapAPI.Models.User;
using System.Net.Http.Headers;
using System.Text;
using static System.Net.Mime.MediaTypeNames;
using OpenSenseMapAPI.Utils.TypedHttpClient;
using OneOf;
using OneOf.Types;

namespace OpenSenseMapAPI.Services
{
    public class UserService
    {
        private readonly ILogger<UserService> _logger;
        private readonly OpenSenseMapHttpClient _openSenseMapHttpClient;

        public UserService(ILogger<UserService> logger, OpenSenseMapHttpClient openSenseMapHttpClient)
        {
            _logger = logger;
            _openSenseMapHttpClient = openSenseMapHttpClient;
        }

        public async Task<OpenSenseMapRegisterUserResponse> RegisterUserAsync(User input)
        {
            try
            {
                var requestBody = new OpenSenseMapRegisterUserRequest
                {
                    email = input.Email,
                    password = input.Password,
                    name = input.Name
                };

                var requestBodyJson = new StringContent(System.Text.Json.JsonSerializer.Serialize(requestBody), Encoding.UTF8, Application.Json);

                using var httpResponseMessage = await _openSenseMapHttpClient.GetHttpClient().PostAsync("/users/register", requestBodyJson);

                var responseBody = await httpResponseMessage.Content.ReadFromJsonAsync<OpenSenseMapRegisterUserResponse>();

                if (responseBody is null)
                {
                    throw new Exception("Failed to deserialize response body");
                }

                responseBody.statusCode = httpResponseMessage.StatusCode;

                return responseBody;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while registering user - {input}", System.Text.Json.JsonSerializer.Serialize(input));
                throw;
            }
        }

        public async Task<OneOf<OpenSenseMapLoginUserResponse, None>> LoginUserAsync(UserLogin input)
        {
            try
            {
                var requestBody = new OpenSenseMapLoginUserRequest
                {
                    email = input.Email,
                    password = input.Password
                };

                var requestBodyJson = new StringContent(System.Text.Json.JsonSerializer.Serialize(requestBody), Encoding.UTF8, Application.Json);

                using var httpResponseMessage = await _openSenseMapHttpClient.GetHttpClient().PostAsync("/users/sign-in", requestBodyJson);

                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    return new None();
                }

                var responseBody = await httpResponseMessage.Content.ReadFromJsonAsync<OpenSenseMapLoginUserResponse>();

                if (responseBody is null)
                {
                    throw new Exception("Failed to deserialize response body");
                }

                return responseBody;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while logging in user - {input}", System.Text.Json.JsonSerializer.Serialize(input));
                throw;
            }
        }

        public async Task<OneOf<True,False>> LogoutUserAsync(string token)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, "/users/sign-out");

                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                using var httpResponseMessage = await _openSenseMapHttpClient.GetHttpClient().SendAsync(request);

                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    return new False();
                }

                return new True();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error while logging out user - {token}", token);
                throw;
            }
        }
    }
}
