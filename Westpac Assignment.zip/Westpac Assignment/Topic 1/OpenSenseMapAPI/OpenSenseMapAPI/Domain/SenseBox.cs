﻿namespace OpenSenseMapAPI.Domain
{
    public class SenseBox
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Exposure { get; set; }
        public string Model { get; set; }
        public DateTimeOffset LastMeasurementAt { get; set; }
        public string? Weblink { get; set; }
        public string? Description { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
        public List<string> Grouptag { get; set; }
        public CurrentLocation CurrentLocation { get; set; }
        public string? Image { get; set; }
        public List<Sensor> Sensors { get; set; }
    }

    public class CurrentLocation 
    {
        public string Type { get; set; }
        public List<decimal> Coordinates { get; set; }
        public DateTimeOffset Timestamp { get; set; }

    }

    public class Sensor
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string SensorType { get; set; }
        public string Unit { get; set; }
        public string? Icon { get; set; }
        public Measurement? LastMeasurement { get; set; }

    }

    public class Measurement
    {
        public string Value { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
    }

}
