﻿using OpenSenseMapAPI.Domain;

namespace OpenSenseMapAPI.Models.SenseBox
{
    public class SenseBoxDTO
    {
        public string _id { get; set; }
        public string name { get; set; }
        public string exposure { get; set; }
        public string model { get; set; }
        public DateTimeOffset lastMeasurementAt { get; set; }
        public string? weblink { get; set; }
        public string? description { get; set; }
        public DateTimeOffset createdAt { get; set; }
        public DateTimeOffset updatedAt { get; set; }
        public List<string> grouptag { get; set; }
        public CurrentLocationDTO currentLocation { get; set; }
        public string? image { get; set; }
        public List<SensorDTO> sensors { get; set; }

        public Domain.SenseBox ToDomain()
        {
            return new Domain.SenseBox
            {
                Id = _id,
                Name = name,
                Exposure = exposure,
                Model = model,
                LastMeasurementAt = lastMeasurementAt,
                Weblink = weblink,
                Description = description,
                CreatedAt = createdAt,
                UpdatedAt = updatedAt,
                Grouptag = grouptag,
                CurrentLocation = currentLocation.ToDomain(),
                Image = image,
                Sensors = sensors.Select(s => s.ToDomain()).ToList()
            };
        }
    }

    public class CurrentLocationDTO
    {
        public string type { get; set; }
        public List<decimal> coordinates { get; set; }
        public DateTimeOffset timestamp { get; set; }

        public CurrentLocation ToDomain()
        {
            return new CurrentLocation
            {
                Type = type,
                Coordinates = coordinates,
                Timestamp = timestamp
            };
        }
    }

    public class SensorDTO
    {
        public string _id { get; set; }
        public string title { get; set; }
        public string sensorType { get; set; }
        public string unit { get; set; }
        public string? icon { get; set; }
        public MeasurementDTO? lastMeasurement { get; set; }

        public Sensor ToDomain()
        {
            return new Sensor
            {
                Id = _id,
                Title = title,
                SensorType = sensorType,
                Unit = unit,
                Icon = icon,
                LastMeasurement = lastMeasurement?.ToDomain()
            };
        }
    }

    public class MeasurementDTO
    {
        public string value { get; set; }
        public DateTimeOffset createdAt { get; set; }
        public Measurement ToDomain()
        {
            return new Measurement
            {
                Value = value,
                CreatedAt = createdAt
            };
        }
    }
}
