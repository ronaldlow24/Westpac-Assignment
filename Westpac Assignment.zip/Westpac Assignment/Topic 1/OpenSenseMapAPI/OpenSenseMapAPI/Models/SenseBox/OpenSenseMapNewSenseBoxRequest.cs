﻿using OpenSenseMapAPI.Contracts.SenseBox;

namespace OpenSenseMapAPI.Models.User
{
    public class OpenSenseMapNewSenseBoxRequest
    {
        public string name { get; set; }
        public string exposure { get; set; }
        public string model { get; set; }
        public OpenSenseMapNewSenseBoxRequestSenseBoxLocation location { get; set; }
    }

    public class OpenSenseMapNewSenseBoxRequestSenseBoxLocation
    {
        public decimal lat { get; set; }
        public decimal lng { get; set; }
        public decimal height { get; set; }
    }
}
