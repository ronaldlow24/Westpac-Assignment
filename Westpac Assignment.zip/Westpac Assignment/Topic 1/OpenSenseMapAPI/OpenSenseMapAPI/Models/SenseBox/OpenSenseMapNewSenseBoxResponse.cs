﻿using OpenSenseMapAPI.Contracts.SenseBox;
using OpenSenseMapAPI.Models.SenseBox;

namespace OpenSenseMapAPI.Models.User
{
    public class OpenSenseMapNewSenseBoxResponse
    {
        public string message { get; set; }
        public SenseBoxDTO data { get; set; }
    }
}
