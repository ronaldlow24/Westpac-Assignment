﻿using OpenSenseMapAPI.Models.User.Base;
using System.Net;

namespace OpenSenseMapAPI.Models.User
{
    public class OpenSenseMapRegisterUserResponse : OpenSenseMapUserManagementBaseResponse
    {
        public HttpStatusCode statusCode { get; set; }
    }
}
