﻿namespace OpenSenseMapAPI.Models.User
{
    public class OpenSenseMapLoginUserRequest
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}
