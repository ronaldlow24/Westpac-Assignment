﻿namespace OpenSenseMapAPI.Models.User
{
    public class OpenSenseMapLogoutUserResponse
    {
        public string code { get; set; }
        public string message { get; set; }
    }
}
