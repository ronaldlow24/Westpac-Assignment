﻿namespace OpenSenseMapAPI.Models.User.Base
{
    public abstract class OpenSenseMapUserManagementBaseResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string token { get; set; }
        public string refreshToken { get; set; }
        public object data { get; set; }
    }
}
