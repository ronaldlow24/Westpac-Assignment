﻿using OpenSenseMapAPI.Models.User.Base;

namespace OpenSenseMapAPI.Models.User
{
    public class OpenSenseMapLoginUserResponse : OpenSenseMapUserManagementBaseResponse
    {
     
    }
}
